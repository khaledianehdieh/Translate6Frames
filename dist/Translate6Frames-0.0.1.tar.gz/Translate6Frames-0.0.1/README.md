# Translate6frame package

This tool is used to translate RNA/DNA sequences to six possible frames (reverse/complement). It takes a fasta file as an input and returns six fasta files (one for each frame) and one csv file. 
